#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import re

class RobotStartNode(Node):
    def __init__(self):
        super().__init__('robot_start_node')
        self.subscription = self.create_subscription(String, 'feedback_topic', self.feedback_callback, 10)
        self.robot_start_subscription = self.create_subscription(String, 'robot_start_topic', self.robot_start_callback, 10)  # Subscription to receive start signal
        self.get_logger().info("Robot Start Node has been initialized and is waiting for orders to complete...")

    def feedback_callback(self, msg):
        # Check if the message contains the "completed" status
        if "has been completed" in msg.data:
            # Extract the table number from the message
            match = re.search(r"Table (\d+)", msg.data)
            if match:
                table_number = match.group(1)
                self.get_logger().info(f"Order completed. Robot is preparing to depart to Table {table_number}")
            else:
                self.get_logger().info("Could not find table number in the message")

    def robot_start_callback(self, msg):
        # This callback is triggered when the robot start signal is received
        self.get_logger().info(f"Received robot start signal: {msg.data}")
        # Extract table number from the message and simulate robot departure
        match = re.search(r"Table (\d+)", msg.data)
        if match:
            table_number = match.group(1)
            self.get_logger().info(f"Robot is departing to Table {table_number}")
        else:
            self.get_logger().info("No valid table number found in the robot start message")

def main(args=None):
    rclpy.init(args=args)
    node = RobotStartNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
