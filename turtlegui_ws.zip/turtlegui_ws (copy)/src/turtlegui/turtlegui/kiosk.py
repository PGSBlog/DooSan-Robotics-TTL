#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import tkinter as tk
from tkinter import ttk
import threading

class PublisherGUI(Node):
    def __init__(self):
        super().__init__('publisher_gui')
        self.publisher = self.create_publisher(String, 'example_topic', 10)
        self.feedback_subscriber = self.create_subscription(String, 'feedback_topic', self.feedback_callback, 10)
        
        # Main window setup
        self.root = tk.Tk()
        self.root.title("ROS2 Publisher GUI")
        self.root.geometry("400x600")
        self.root.resizable(False, False)
        
        # Create main container
        self.main_container = ttk.Frame(self.root)
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        # Upper frame for kiosk
        self.upper_frame = ttk.Frame(self.main_container, padding="5")
        self.upper_frame.pack(fill=tk.X)
        
        # Lower frame for selected menu
        self.lower_frame = ttk.Frame(self.main_container, padding="5")
        self.lower_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title label
        title_label = ttk.Label(self.upper_frame, text="Order Kiosk", font=("Helvetica", 16, "bold"))
        title_label.pack(pady=(5, 10))
        
        # Menu items with quantity controls
        self.menu_quantities = {}  # Store quantities for each menu item
        self.create_menu_buttons()
        
        # Table number frame
        table_frame = ttk.Frame(self.upper_frame)
        table_frame.pack(pady=10)
        
        table_label = ttk.Label(table_frame, text="테이블 번호:", font=("Helvetica", 10))
        table_label.pack(side=tk.LEFT, padx=5)
        
        self.table_number_var = tk.StringVar()
        self.table_number_entry = ttk.Entry(table_frame, textvariable=self.table_number_var, width=8)
        self.table_number_entry.pack(side=tk.LEFT)
        
        # Order button
        self.order_button = ttk.Button(self.upper_frame, text="Order", command=self.publish_order, style="Accent.TButton")
        self.order_button.pack(pady=5)

        # Selected menu display section
        selected_title = ttk.Label(self.lower_frame, text="Selected Menu", font=("Helvetica", 14, "bold"))
        selected_title.pack(pady=(5, 10))
        
        # Create a white background frame for selected items
        self.selected_frame = ttk.Frame(self.lower_frame, style="Selected.TFrame")
        self.selected_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Configure style for white background
        style = ttk.Style()
        style.configure("Selected.TFrame", background="white")
        
        # Selected items display
        self.selected_items_var = tk.StringVar(value="")
        self.selected_items_label = ttk.Label(
            self.selected_frame,
            textvariable=self.selected_items_var,
            justify=tk.LEFT,
            background="white"
        )
        self.selected_items_label.pack(padx=10, pady=5, anchor=tk.NW)
        
        # Status message display
        self.status_var = tk.StringVar()
        self.status_label = ttk.Label(
            self.selected_frame,
            textvariable=self.status_var,
            background="white",
            font=("Helvetica", 11)
        )
        self.status_label.pack(pady=5)

        # Flag to track if order is pending
        self.order_pending = False

    def create_menu_buttons(self):
        menu_frame = ttk.Frame(self.upper_frame)
        menu_frame.pack(fill=tk.X, pady=5)
        
        menu_items = ["Pizza", "Pasta", "Salad", "Soup"]
        for idx, item in enumerate(menu_items):
            item_frame = ttk.Frame(menu_frame)
            item_frame.pack(fill=tk.X, pady=2)
            
            menu_button = ttk.Button(
                item_frame,
                text=item,
                command=lambda i=item: self.add_menu_item(i),
                width=15
            )
            menu_button.pack(side=tk.LEFT, padx=2)
            
            self.menu_quantities[item] = tk.IntVar(value=0)
            quantity_label = ttk.Label(item_frame, textvariable=self.menu_quantities[item], width=3)
            quantity_label.pack(side=tk.LEFT, padx=5)
            
            minus_button = ttk.Button(
                item_frame,
                text="-",
                command=lambda i=item: self.decrease_quantity(i),
                width=3
            )
            minus_button.pack(side=tk.LEFT, padx=1)
            
            plus_button = ttk.Button(
                item_frame,
                text="+",
                command=lambda i=item: self.increase_quantity(i),
                width=3
            )
            plus_button.pack(side=tk.LEFT, padx=1)

    def add_menu_item(self, item):
        if self.order_pending:
            # Reset everything if there was a pending order
            self.order_pending = False
            self.reset_selections()
        
        if self.menu_quantities[item].get() == 0:
            self.increase_quantity(item)

    def increase_quantity(self, item):
        if not self.order_pending:
            current = self.menu_quantities[item].get()
            self.menu_quantities[item].set(current + 1)
            self.update_selected_display()
            self.status_var.set("")  # Clear any previous status message

    def decrease_quantity(self, item):
        if not self.order_pending:
            current = self.menu_quantities[item].get()
            if current > 0:
                self.menu_quantities[item].set(current - 1)
                self.update_selected_display()
                self.status_var.set("")  # Clear any previous status message

    def update_selected_display(self):
        selected_items = []
        for item, quantity in self.menu_quantities.items():
            if quantity.get() > 0:
                selected_items.append(f"{item} X {quantity.get()}")
        
        if selected_items:
            self.selected_items_var.set("\n".join(selected_items))
        else:
            self.selected_items_var.set("")

    def publish_order(self):
        if self.order_pending:
            return

        table_number = self.table_number_var.get()
        selected_items = []
        
        for item, quantity in self.menu_quantities.items():
            if quantity.get() > 0:
                selected_items.append(f"{item} X {quantity.get()}")
        
        if not selected_items or not table_number:
            self.status_var.set("메뉴와 테이블 번호를 입력해주세요")
            return
        
        order_message = f"Table {table_number}: {', '.join(selected_items)}"
        msg = String()
        msg.data = order_message
        self.publisher.publish(msg)
        self.order_pending = True

    def feedback_callback(self, msg):
        if "accepted" in msg.data.lower():
            self.status_var.set("주문이 접수되었습니다")
            self.order_pending = True
        elif "rejected" in msg.data.lower():
            self.status_var.set("주문이 거절되었습니다")
            self.order_pending = True

    def reset_selections(self):
        for quantity in self.menu_quantities.values():
            quantity.set(0)
        self.table_number_var.set("")
        self.selected_items_var.set("")
        self.status_var.set("")

    def run(self):
        threading.Thread(target=self._spin_ros, daemon=True).start()
        self.root.mainloop()

    def _spin_ros(self):
        rclpy.spin(self)

def main(args=None):
    rclpy.init(args=args)
    node = PublisherGUI()
    
    try:
        node.run()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()