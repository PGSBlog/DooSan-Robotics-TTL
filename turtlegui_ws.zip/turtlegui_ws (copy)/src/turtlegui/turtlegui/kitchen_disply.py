#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
from datetime import datetime
import re

class SubscriberGUI(Node):
    def __init__(self):
        super().__init__('subscriber_gui')
        self.subscription = self.create_subscription(String, 'example_topic', self.listener_callback, 10)
        self.feedback_publisher = self.create_publisher(String, 'feedback_topic', 10)
        self.robot_start_publisher = self.create_publisher(String, 'robot_start_topic', 10)
        
        # Main window setup
        self.root = tk.Tk()
        self.root.title("ROS2 Subscriber GUI")
        self.root.geometry("500x400")
        
        self.main_frame = ttk.Frame(self.root, padding="10")
        self.main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Title label with custom style
        title_label = ttk.Label(self.main_frame, text="Kitchen Display", font=("Helvetica", 20, "bold"))
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 15))
        
        # Message display
        self.message_display = scrolledtext.ScrolledText(
            self.main_frame, 
            wrap=tk.WORD, 
            width=50, 
            height=12, 
            font=("Helvetica", 12)
        )
        self.message_display.grid(row=1, column=0, columnspan=3, pady=(0, 15))
        
        # Buttons frame
        button_frame = ttk.Frame(self.main_frame)
        button_frame.grid(row=2, column=0, columnspan=3, pady=(0, 10))
        
        # Accept/Reject/Complete buttons
        self.accept_button = ttk.Button(
            button_frame, 
            text="Accept", 
            command=lambda: self.process_order("accepted"), 
            width=15
        )
        self.accept_button.grid(row=0, column=0, padx=5)

        self.reject_button = ttk.Button(
            button_frame, 
            text="Reject", 
            command=lambda: self.process_order("rejected"), 
            width=15
        )
        self.reject_button.grid(row=0, column=1, padx=5)
        
        self.complete_button = ttk.Button(
            button_frame, 
            text="Complete", 
            command=lambda: self.process_order("completed"), 
            width=15
        )
        self.complete_button.grid(row=0, column=2, padx=5)
        self.complete_button.configure(state='disabled')

        # Order tracking
        self.current_order = None
        self.order_status = None

    def listener_callback(self, msg):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.current_order = msg.data
        self.order_status = None
        formatted_msg = f"[{timestamp}] New Order: {msg.data}\n"
        
        self.root.after(0, self.update_button_states, True, False)
        self.root.after(0, self.update_display, formatted_msg)
        
    def update_display(self, message):
        self.message_display.configure(state='normal')
        self.message_display.insert(tk.END, message)
        self.message_display.see(tk.END)
        self.message_display.configure(state='disabled')

    def update_button_states(self, accept_reject_enabled, complete_enabled):
        state_accept_reject = 'normal' if accept_reject_enabled else 'disabled'
        state_complete = 'normal' if complete_enabled else 'disabled'
        
        self.accept_button.configure(state=state_accept_reject)
        self.reject_button.configure(state=state_accept_reject)
        self.complete_button.configure(state=state_complete)

    def process_order(self, status):
        if not self.current_order:
            return

        if status in ["accepted", "rejected"]:
            self.order_status = status
            result_message = f"Order {self.current_order} has been {status}.\n"
            self.update_display(result_message)
            
            feedback_msg = String()
            feedback_msg.data = f"Order for {self.current_order} has been {status}."
            self.feedback_publisher.publish(feedback_msg)
            
            self.root.after(0, self.update_button_states, False, status == "accepted")

        elif status == "completed":
            if self.order_status == "accepted":
                result_message = "Order complete\n"
                self.update_display(result_message)
                
                feedback_msg = String()
                feedback_msg.data = f"Order for {self.current_order} has been {status}."
                self.feedback_publisher.publish(feedback_msg)

                table_number = self.extract_table_number(self.current_order)
                if table_number:
                    robot_start_msg = String()
                    robot_start_msg.data = f"Start robot for Table {table_number}"
                    self.robot_start_publisher.publish(robot_start_msg)
                
                self.current_order = None
                self.order_status = None
                self.root.after(0, self.update_button_states, False, False)

    def extract_table_number(self, order):
        match = re.search(r"Table (\d+)", order)
        if match:
            return match.group(1)
        return None

    def run(self):
        threading.Thread(target=self._spin_ros, daemon=True).start()
        self.root.mainloop()

    def _spin_ros(self):
        rclpy.spin(self)

def main(args=None):
    rclpy.init(args=args)
    node = SubscriberGUI()
    
    try:
        node.run()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()