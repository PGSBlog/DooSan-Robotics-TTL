from setuptools import find_packages, setup

package_name = 'turtlegui'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='shin',
    maintainer_email='ehddbs1211@naver.com',
    description='A ROS2 package with a GUI for order publishing and feedback display.',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'publisher_gui = turtlegui.publisher_gui:main',
            'subscriber_gui = turtlegui.subscriber_gui:main',
            'robot_start_node = turtlegui.robot_start:main',  # 로봇 스타트 엔트리 포인트 추가
        ],
    },
)
